# plot generic for likelihood

plot.likelihood <- function(x, theta,...) {
  if (missing(theta)){stop("You must enter a theta range!")}
  theta <- theta
  likelihood <- suppressWarnings(expr =  x@func(theta = theta)) # suppress warning from t dist accuracy
  df <- tibble(theta = theta, likelihood = likelihood)

  if(x@dist.type == "continuous"){
    p <- ggplot(data = df, aes(x = theta, y = likelihood)) + geom_line(na.rm = T) + theme_minimal()
  }
  if(x@dist.type == "discrete"){
    p <- ggplot(data = df, aes(x = theta, y = likelihood)) + geom_point(na.rm = T) + theme_minimal()
  }
  return(p)
}

# as_tibble for likelihood
as_tibble.likelihood <- function(x, theta, ...){
  if (missing(theta)){stop("You must enter a theta range!")}
  theta <- theta
  likelihood <- suppressWarnings(expr =  x@func(theta = theta)) # suppress warning from t dist accuracy
  return(tibble(theta = theta,
                likelihood = likelihood))
}


# as_tibble for marginal
as_tibble.marginal <- function(x, theta, ...){
  if (missing(theta)){stop("You must enter a theta range!")}
  theta <- theta
  likelihood <- suppressWarnings(expr =  alt@data$marginal(theta = theta)) # suppress warning from t dist accuracy
  return(tibble(theta = theta,
                likelihood = likelihood))
}


# area under point null
point.null <- function(data.model,null.value){
  if(class(data.model) != "likelihood"){stop("data.model must be a likelihood")}
  data.model@func(theta = null.value)
}

get.prior <- function(alt,theta.range){
  prior.func <- function(theta){alt@K * alt@prior(theta)}
  tibble::tibble(theta = theta.range,
                 likelihood = prior.func(theta.range))
}



`*.likelihood` <-function(e1,e2){
  theta.range = e2$theta.range

  likelihood.func <- e1@func
  prior.func <- e2$func

  # normalise the pior
  if(theta.range[1] != theta.range[2]){
    K = suppressWarnings(1 / integrate(f = prior.func, lower = theta.range[1], upper = theta.range[2])$value)
  } else{
    K = 1
  }
  marginal <- function(theta){suppressWarnings(likelihood.func(theta = theta) * (K * prior.func(theta = theta)))}

  if(theta.range[1] != theta.range[2]){
    alt.val <- suppressWarnings(integrate(marginal,theta.range[1],theta.range[2])$value)
  } else {
    alt.val <- marginal(theta.range[[1]])
  }

  alt.func <- marginal
  data = list(
    integral = alt.val,
    marginal = marginal,
    prior.normalising.constant = K)

  new(Class = 'marginal',
      data = data,
      K = K,
      lik = likelihood.func,
      prior = prior.func,
      theta.range = theta.range)

}

# non-central t likelihood
t.lik <- function(center,df){
  lik.func <- function(theta){dt(sqrt(df + 1)*center,df,sqrt(df + 1)*theta)}
  params = list(center = center, df = df)
  desc = paste0("Parameters\nCenter: ",params$center,"\nDF: ",params$df)
  new(Class = 'likelihood',
      data = list(lik.type = "non-central t", parameters = params),
      func = lik.func,
      desc = desc,
      dist.type = "continuous")


}

# Shifted scaled t likelihood
scaled.shifted.t.lik <- function(center, scale, df){
  lik.func <- function(theta){dt((center - theta) / scale, df = df)}
  params = list(center = center, scale = scale, df = df)
  desc = paste0("Parameters\nCenter: ",params$center,"\nScale: ",params$scale,"\nDF: ",params$df)
  new(Class = 'likelihood',
      data = list(lik.type = "Shifted and Scaled t", parameters = params),
      func = lik.func,
      desc = desc,
      dist.type = "continuous")

}

# gaussian likelihood
norm.lik <- function(center, scale){
  lik.func <- function(theta){dnorm(x = center, mean = theta, sd = scale)}
  params = list(center = center, scale = scale, df = df)
  desc = paste0("Parameters\nCenter: ",params$center,"\nScale: ",params$scale)
  new(Class = 'likelihood',
      data = list(lik.type = "normal", parameters = params),
      func = lik.func,
      desc = desc,
      dist.type = "continuous")
}


GenSynthSample = function(mean, sd, se, n){
  inputs = as.list(sys.call())
  if(sum(names(inputs) %in% c("se","sd")) == 2){
    stop("input se OR sd")
  }

  if("se" %in% names(inputs)){
    sd = se * sqrt(n)
  }

  x = mean + sd * scale(rnorm(n, 0, 0))
  return(as.numeric(x))
}


tidy.BFBayesFactor <- function(x, ...){
  nullInterval = x@numerator[[1]]@prior$nullInterval

  if(class(x@numerator[[1]])[1] == "BFoneSample"){

    mean = mean(x@data$y)
    return(tibble::tibble(
      estimate = mean,
      BF10 = exp(x@bayesFactor$bf),
      BF01 = 1/exp(x@bayesFactor$bf),
      rscale = x@numerator[[1]]@prior$rscale,
      priortype = x@denominator@type,
      null = x@denominator@longName,
      nullInterval = ifelse(is.null(nullInterval),NA,nullInterval),
      method = class(x@numerator[[1]])[1]))



  } else {


    group.means = by(x@data$y,x@data$group, FUN = base::mean)

    return(tibble::tibble(estimate1 =
                            group.means[[1]],
                          estimate2 =
                            group.means[[2]],
                          BF10 = exp(x@bayesFactor$bf),
                          BF01 = 1/exp(x@bayesFactor$bf),
                          rscale = x@numerator[[1]]@prior$rscale,
                          priortype = x@denominator@type,
                          null = x@denominator@longName,
                          nullInterval = ifelse(is.null(nullInterval),NA,nullInterval),
                          method = class(x@numerator[[1]])[1]))
  }

}

loadpackages = function(){
  suppressMessages(require(tidyverse))
  suppressMessages(require(brms))
  suppressMessages(require(patchwork))
  suppressMessages(require(bayesplay))
  suppressMessages(require(BayesFactor))
  suppressMessages(require(logspline))
  suppressMessages(require(furrr))
  suppressMessages(require(tidyverse))
  suppressMessages(require(magrittr))
  suppressMessages(require(logspline))
  suppressMessages(require(patchwork))
  suppressMessages(require(IRdisplay))
  suppressMessages(require(broom))
  suppressMessages(require(glue))

}

