likelihood <- setClass(
  "likelihood",
  slots = list(
    data = "list",
    func = "function",
    desc = "character",
    dist.type = "character"
  )
)

# posterior
posterior <- setClass(
  "posterior",
  slots = list(
    data = "list",
    K = "numeric",
    lik = "function",
    prior = "function",
    theta.range = "numeric"
  )
)
